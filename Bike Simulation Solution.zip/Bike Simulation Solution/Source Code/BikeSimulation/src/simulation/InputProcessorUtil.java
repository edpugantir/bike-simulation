package simulation;
import java.util.Scanner;

import simulation.props.Direction;
import simulation.props.ExceptMesgs;
import simulation.props.OperationCategory;

/*
 * @author edpuganti
 * This class does the task of handling user input 
 * */
public class InputProcessorUtil {

	BikeGridTracker bikeGridTracker = null;
	
	public InputProcessorUtil(BikeGridTracker bikeGridTracker) {
		this.bikeGridTracker = bikeGridTracker;
	}
	
	//This function iteratively seeks user input and handles it
	public void process() 
	{
		// Using Scanner for Getting Input from User 
        Scanner in = new Scanner(System.in);
        
		while(true) {
			System.out.println("Enter command: \'PLACE <X>,<Y>,<Facing-direction>\', FORWARD ,TURN_LEFT, TURN_RIGHT, GPS_REPORT,EXIT");
	        String userInput = in.nextLine();
	        
	        //when the user issues the EXIT command we break and exit the simulation
	        if(userInput.equalsIgnoreCase("EXIT")) {
	        	System.out.println("Terminating the simulation");
	        	break;
	        }
	        else {
	        	this.processInput(userInput);
	        }
		}
	}
	
	
	//This function processes the input and routes it accordinglhy.
	public void processInput(String userInput) {
		
		String tokens[] = userInput.split(" ", 2);
		
        if( OperationCategory.isValidOperation(tokens[0]) ) {
        	
        	if(tokens[0].equalsIgnoreCase(OperationCategory.PLACE.toString()) && tokens.length>1) {
        		String params[] = tokens[1].split(",");
        		
        		if (params.length == 3) {
        			int x = -1;
        			int y = -1;
        			try {
        				x = Integer.parseInt(params[0]);
        				y = Integer.parseInt(params[1]);
        			} catch(NumberFormatException nfe) {
        				System.out.println(ExceptMesgs.ERROR_PLACE_COMMAND_FORMAT);	
        			}
        			String direction = params[2];
        				
        			try {
        				Coordinate placementCoord = new Coordinate(x, y, Direction.getDirectionByName(direction));
						bikeGridTracker.placeTheBike(placementCoord);
					} catch (Exception e) {
						System.out.println(e.getMessage());
					}
        			
        		}else {
        			System.out.println(ExceptMesgs.ERROR_PLACE_COMMAND_FORMAT);
        		}        		
        	}
        	else if(tokens[0].equalsIgnoreCase(OperationCategory.GPS_REPORT.toString())){
				Coordinate coordinate;
				try {
					coordinate = bikeGridTracker.getGPS();
					System.out.format("X=%d , Y=%d , Direction=%s\n", coordinate.getX(), coordinate.getY(), coordinate.getDirection().toString());
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
	        	
        	}
        	else if(tokens[0].equalsIgnoreCase(OperationCategory.TURN_LEFT.toString())) {
        		try {
					bikeGridTracker.turnLeft();
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
        	}
        	else if(tokens[0].equalsIgnoreCase(OperationCategory.TURN_RIGHT.toString())) {
        		try {
					bikeGridTracker.turnRight();
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
        	}
        	else if(tokens[0].equalsIgnoreCase(OperationCategory.FORWARD.toString())) {
        		try {
					bikeGridTracker.forwardMove();
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
        	}
        	Coordinate coordinate;
			try {
				coordinate = bikeGridTracker.getGPS();
				System.out.format("::::::::::CURRENT_BIKE_LOCATION:::::::X=%d , Y=%d , Direction=%s\n\n", coordinate.getX(), coordinate.getY(), coordinate.getDirection().toString());
			} catch (Exception e) {
			}
        }else {
        	System.out.println("Invalid Input");
        }			
	}
	
}
