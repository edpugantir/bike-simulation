package simulation.props;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/*
 * @author edpuganti
 * This enumeration represents the valid directions and 
 * functions associated with them*/
public enum Direction {
	EAST(0),
	NORTH(1),
	WEST(2),
	SOUTH(3);
	
	private final int indicatorValue;

    private static final Map<Integer, Direction> BY_INDICATOR_VAL = new HashMap<>();
    private static final Map<String, Direction> BY_DIRECTION_NAME = new HashMap<>();
	
	 static {
	        for (Direction d: values()) {
	        	BY_INDICATOR_VAL.put(d.indicatorValue, d);
	        	BY_DIRECTION_NAME.put(d.toString(), d);
	        }
	    }
	 
	Direction(int value){
		this.indicatorValue = value;
	}
	
	public int getIndicatorValue() {
		return this.indicatorValue;
	}

	
	public Direction turnLeft() {
		int indicatorValue = this.getIndicatorValue();
		
		if(indicatorValue == this.values().length - 1) {
			indicatorValue = 0 ;
		}else {
			indicatorValue++;
		}
		
		return this.getCorrespondingDirection(indicatorValue);
	}
	
	public Direction turnRight() {
		
		int indicatorValue = this.getIndicatorValue();
		
		if(indicatorValue == 0 ) {
			indicatorValue = this.values().length - 1 ;
		}else {
			indicatorValue--;
		}
		
		return this.getCorrespondingDirection(indicatorValue);
	}
	
	
	public Direction getCorrespondingDirection(int value) {
		return BY_INDICATOR_VAL.get(value);
	}

	
	public static boolean isValidDirection(String direction) {
		return BY_DIRECTION_NAME.containsKey(direction.toUpperCase());
	}
	
	public static Direction getDirectionByName(String direction) {
		return BY_DIRECTION_NAME.get(direction.toUpperCase());
	}
}
