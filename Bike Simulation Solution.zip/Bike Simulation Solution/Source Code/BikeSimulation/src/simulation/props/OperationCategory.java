package simulation.props;
import java.util.HashMap;
import java.util.Map;

/*
 * @author edpuganti
 * This enumeration represents the valid Operations or Commands and 
 * functions associated with them
 *
 */
public enum OperationCategory {
	
	PLACE("PLACE"),
	FORWARD("FORWARD"),
	TURN_LEFT("TURN_LEFT"),
	TURN_RIGHT("TURN_RIGHT"),
	GPS_REPORT("GPS_REPORT"),
	EXIT("EXIT");
	
	private final String operation;
	
	private static final Map<String, OperationCategory> BY_OP_NAMES = new HashMap<>();
		
	static {
		for (OperationCategory op: values()) {
			BY_OP_NAMES.put(op.getOperation(), op);
		}
	}
	
	public static boolean isValidOperation(String operation) {
		if(BY_OP_NAMES.containsKey(operation.toUpperCase())) {
			return true;
		}
		else {
			return false;
		}
	}
		 
	OperationCategory(String operation) {
        this.operation = operation;
    }
	
	public String getOperation() {
		return this.operation;
	}

}
