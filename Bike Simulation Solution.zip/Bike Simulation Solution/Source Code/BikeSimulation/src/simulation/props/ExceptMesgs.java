package simulation.props;

/**
 * 
 * @author edpuganti
 * This class has exception messages.
 * 
 */
public class ExceptMesgs {
	public static String ERROR_PLACE_COMMAND_FORMAT = "Correct format of PLACE command is: \'PLACE <X>,<Y>,<Facing-direction>\'";
	public static String ERROR_BIKE_CANT_GO_OUT = "Bike can not be moved out of the Grid.\n";
	public static String ERROR_BIKE_NOT_PLACED = "Bike is not placed in the grid.\n";
	public static String ERROR_INVALID_DIRECTION = "Invalid Direction.\n";
}
