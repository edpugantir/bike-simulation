package simulation;
import java.util.Scanner;

import simulation.BikeGridTracker;

public class BikeSimulationMain {
	
	
	public static void main(String args[]) {
		
		BikeGridTracker bikeGridTracker = new BikeGridTracker(7, 7);
		
		InputProcessorUtil inputProcUtil = new InputProcessorUtil(bikeGridTracker);
		
		inputProcUtil.process();
	}

}
