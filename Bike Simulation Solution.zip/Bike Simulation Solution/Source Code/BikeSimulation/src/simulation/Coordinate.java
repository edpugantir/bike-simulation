package simulation;

import simulation.props.Direction;

public class Coordinate {

	private int x;
	private int y;
	private Direction direction;
	
	
	public Coordinate(int x, int y, Direction direction) {
		super();
		this.x = x;
		this.y = y;
		this.direction = direction;
	}

	public Direction getDirection() {
		return direction;
	}

	public void setDirection(Direction direction) {
		this.direction = direction;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}
	
	@Override
	public boolean equals(Object o) {
		 // If the object is compared with itself then return true   
        if (o == this) { 
            return true; 
        } 
  
        /* Check if o is an instance of Coordinate or not 
          "null instanceof [type]" also returns false */
        if (!(o instanceof Coordinate)) { 
            return false; 
        } 
        
        Coordinate c = (Coordinate)o;
        
        return (c.getX()==this.x) && (c.getY()==this.y) 
        		&& (c.getDirection().toString().equals(this.direction.toString()));  
        
	}
	
	@Override
	public int hashCode() {
		return this.x;
	}
}
