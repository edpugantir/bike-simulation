package simulation.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import simulation.BikeGridTracker;
import simulation.Coordinate;
import simulation.props.Direction;
import simulation.props.ExceptMesgs;

class BikeGridTrackerTurningTests {
	static BikeGridTracker bikeGridTracker = null;
	
	@BeforeAll
	public static void coreSetup() {
		bikeGridTracker = new BikeGridTracker(5, 5);
	}
	
	@BeforeEach
	public void setUp() throws Exception {
		bikeGridTracker.placeTheBike(new Coordinate(1, 1, Direction.getDirectionByName(Direction.EAST.toString())));
	}
	
	
	@Test
	void testTurnRight() {
		
		try {
			
			bikeGridTracker.turnRight();
			assertEquals( new Coordinate(1, 1, Direction.SOUTH) , bikeGridTracker.getGPS());
			bikeGridTracker.turnRight();
			assertEquals( new Coordinate(1, 1, Direction.WEST) , bikeGridTracker.getGPS());
			bikeGridTracker.turnRight();
			assertEquals( new Coordinate(1, 1, Direction.NORTH) , bikeGridTracker.getGPS());
			bikeGridTracker.turnRight();
			assertEquals( new Coordinate(1, 1, Direction.EAST) , bikeGridTracker.getGPS());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	void testTurnLeft() {
		try {
			bikeGridTracker.turnLeft();
			assertEquals( new Coordinate(1, 1, Direction.NORTH) , bikeGridTracker.getGPS());
			bikeGridTracker.turnLeft();
			assertEquals( new Coordinate(1, 1, Direction.WEST) , bikeGridTracker.getGPS());
			bikeGridTracker.turnLeft();
			assertEquals( new Coordinate(1, 1, Direction.SOUTH) , bikeGridTracker.getGPS());
			bikeGridTracker.turnLeft();
			assertEquals( new Coordinate(1, 1, Direction.EAST) , bikeGridTracker.getGPS());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	

	@Test
	void testTurnInvalid() {
		try {
			bikeGridTracker.turnLeft();
		} catch (Exception e) {
			assertEquals(ExceptMesgs.ERROR_BIKE_NOT_PLACED , e.getMessage());
		}
		try {
			
			bikeGridTracker.placeTheBike(new Coordinate(1, 110, 
				Direction.getDirectionByName(Direction.EAST.toString())));
			
			bikeGridTracker.turnRight();
		} catch (Exception e) {
			assertEquals(ExceptMesgs.ERROR_BIKE_NOT_PLACED , e.getMessage());
		}
	}
	
	
	
}
