package simulation.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import simulation.BikeGridTracker;
import simulation.Coordinate;
import simulation.props.Direction;
import simulation.props.ExceptMesgs;

class BikeGridTrackerMoveTests {
	BikeGridTracker bikeGridTracker = null;
	
	@BeforeEach
	public  void coreSetup() {
		bikeGridTracker = new BikeGridTracker(5, 5);
	}
	

	@Test
	void testSuccessfulMove() {
		try {
			Coordinate coordinate = new Coordinate(2, 2, Direction.getDirectionByName(Direction.EAST.toString()));
			bikeGridTracker.placeTheBike(coordinate);
			bikeGridTracker.forwardMove();
			coordinate.setX(coordinate.getX()+1);
			assertEquals(coordinate, bikeGridTracker.getGPS() );
			
			bikeGridTracker.forwardMove();
			coordinate.setX(coordinate.getX()+1);
			assertEquals(coordinate, bikeGridTracker.getGPS() );
			
			bikeGridTracker.turnLeft();
			
			bikeGridTracker.forwardMove();
			coordinate.setY(coordinate.getY()+1);
			coordinate.setDirection(Direction.NORTH);
			assertEquals(coordinate, bikeGridTracker.getGPS() );
			
			bikeGridTracker.turnLeft();
			bikeGridTracker.forwardMove();
			coordinate.setX(coordinate.getX()-1);
			coordinate.setDirection(Direction.WEST);
			assertEquals(coordinate, bikeGridTracker.getGPS() );
//			assertEquals(new Coordinate(1, 1, Direction.EAST), bikeGridTracker.getGPS());
			
			bikeGridTracker.turnLeft();
			bikeGridTracker.forwardMove();
			coordinate.setY(coordinate.getY()-1);
			coordinate.setDirection(Direction.SOUTH);
			assertEquals(coordinate, bikeGridTracker.getGPS() );
		
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}

	
	@Test
	void testSuccessMoveFollowedByHittingBoundary() {
		try {
			Coordinate coordinate = new Coordinate(3, 3, Direction.getDirectionByName(Direction.EAST.toString()));
			bikeGridTracker.placeTheBike(coordinate);
			bikeGridTracker.forwardMove();
			coordinate.setX(coordinate.getX()+1);
			assertEquals(coordinate, bikeGridTracker.getGPS() );
			bikeGridTracker.forwardMove();
		} catch (Exception e) {
			assertEquals( ExceptMesgs.ERROR_BIKE_CANT_GO_OUT , e.getMessage());
		}		
	}
	
	
	@Test
	void testWrongPlacementFollowedByMove() {
		try {
			Coordinate coordinate = new Coordinate(30, 30, Direction.getDirectionByName(Direction.EAST.toString()));
			bikeGridTracker.placeTheBike(coordinate);
			
		} catch (Exception e) {
			assertEquals( ExceptMesgs.ERROR_BIKE_NOT_PLACED , e.getMessage());
			try {
				bikeGridTracker.forwardMove();
			}catch(Exception e2) {
				assertEquals(ExceptMesgs.ERROR_BIKE_NOT_PLACED , e2.getMessage() );
			}
		}		
	}
	
	
	@Test
	void testWrongPlacementFollowedByTurnLeft() {
		try {
			Coordinate coordinate = new Coordinate(30, 30, Direction.getDirectionByName(Direction.EAST.toString()));
			bikeGridTracker.placeTheBike(coordinate);
			
		} catch (Exception e) {
			assertEquals( ExceptMesgs.ERROR_BIKE_NOT_PLACED , e.getMessage());
			try {
				bikeGridTracker.turnLeft();
			}catch(Exception e2) {
				assertEquals(e2.getMessage(), ExceptMesgs.ERROR_BIKE_NOT_PLACED);
			}
		}		
	}
	
	@Test
	void testWrongPlacementFollowedByTurnRight() {
		try {
			Coordinate coordinate = new Coordinate(30, 30, Direction.getDirectionByName(Direction.EAST.toString()));
			bikeGridTracker.placeTheBike(coordinate);
			
		} catch (Exception e) {
			assertEquals( ExceptMesgs.ERROR_BIKE_NOT_PLACED , e.getMessage());
			try {
				bikeGridTracker.turnRight();
			}catch(Exception e2) {
				assertEquals(e2.getMessage(), ExceptMesgs.ERROR_BIKE_NOT_PLACED);
			}
		}		
	}
	
	
	@Test
	void testHitNorthWall() {
		try {
			Coordinate coordinate = new Coordinate(4, 4, Direction.getDirectionByName(Direction.EAST.toString()));
			bikeGridTracker.placeTheBike(coordinate);
			bikeGridTracker.turnLeft();
			bikeGridTracker.forwardMove();
		} catch (Exception e) {
			assertEquals( ExceptMesgs.ERROR_BIKE_CANT_GO_OUT, e.getMessage());
		}		
	}
	
	
	@Test
	void testHitWestWall() {
		try {
			Coordinate coordinate = new Coordinate(0, 4, Direction.getDirectionByName(Direction.SOUTH.toString()));
			bikeGridTracker.placeTheBike(coordinate);
			bikeGridTracker.turnRight();
			bikeGridTracker.forwardMove();
		} catch (Exception e) {
			assertEquals( ExceptMesgs.ERROR_BIKE_CANT_GO_OUT, e.getMessage());
		}		
	}
	
	@Test
	void testHitSouthWall() {
		try {
			Coordinate coordinate = new Coordinate(1, 1, Direction.getDirectionByName(Direction.EAST.toString()));
			bikeGridTracker.placeTheBike(coordinate);
			bikeGridTracker.turnRight();
			bikeGridTracker.forwardMove();
			bikeGridTracker.forwardMove();
		} catch (Exception e) {
			assertEquals( ExceptMesgs.ERROR_BIKE_CANT_GO_OUT, e.getMessage());
		}		
	}
	
	@Test
	void testSuccessPlacementThenMoveThenInvalidPlacement() {
		try {
			Coordinate coordinate = new Coordinate(1, 1, Direction.getDirectionByName(Direction.EAST.toString()));
			bikeGridTracker.placeTheBike(coordinate);
			bikeGridTracker.forwardMove();
			coordinate.setX(coordinate.getX()+1);
			assertEquals(coordinate, bikeGridTracker.getGPS() );
			coordinate.setX(coordinate.getX()+100);
			
		} catch (Exception e) {
			assertEquals( ExceptMesgs.ERROR_BIKE_NOT_PLACED, e.getMessage());
		}		
	}
}
