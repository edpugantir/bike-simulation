package simulation.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import simulation.BikeGridTracker;
import simulation.Coordinate;
import simulation.props.Direction;
import simulation.props.ExceptMesgs;

class BikeGridTrackerPlacingTests {
	
	static BikeGridTracker bikeGridTracker = null;
	
	@BeforeAll
	public static void coreSetup() {
		bikeGridTracker = new BikeGridTracker(5, 5);
	}
	
	@BeforeEach
	public void setUp() throws Exception {
	
	}
	
	
	@Test
	public void testPlacingSuccess() throws Exception {
		bikeGridTracker.placeTheBike(new Coordinate(1, 1, Direction.EAST));
		assertEquals(new Coordinate(1, 1, Direction.EAST), bikeGridTracker.getGPS());
	}
	

	@Test
	public void testPlacingFailure() throws Exception {
		
		try {
			bikeGridTracker.placeTheBike(new Coordinate(-1, 1, Direction.EAST));
		}catch(Exception e) {
			assertEquals(ExceptMesgs.ERROR_BIKE_NOT_PLACED, e.getMessage());
		}
	}

	@Test
	public void testPlacingFailureOnEastExtremity() throws Exception {
		
		try {
			bikeGridTracker.placeTheBike(new Coordinate(3, 10, Direction.EAST));
		}catch(Exception e) {
			assertEquals(ExceptMesgs.ERROR_BIKE_NOT_PLACED, e.getMessage());
		}
	}


	@Test
	public void testPlacingFailureOnNorthExtremity() throws Exception {
		BikeGridTracker bikeGridTracker = new BikeGridTracker(5, 5);
		
		try {
			bikeGridTracker.placeTheBike(new Coordinate(10, 3, Direction.EAST));
		}catch(Exception e) {
			assertEquals(ExceptMesgs.ERROR_BIKE_NOT_PLACED, e.getMessage());
		}
	}
	
	@Test
	public void testPlacingFailureOnSouthExtremity() throws Exception {
		BikeGridTracker bikeGridTracker = new BikeGridTracker(5, 5);
		
		try {
			bikeGridTracker.placeTheBike(new Coordinate(3, -1, Direction.EAST));
		}catch(Exception e) {
			assertEquals(ExceptMesgs.ERROR_BIKE_NOT_PLACED, e.getMessage());
		}
	}
	

	@Test
	public void testPlacingFailureOnNorthAndEast() throws Exception {
		
		try {
			bikeGridTracker.placeTheBike(new Coordinate(10, 10, Direction.EAST));
		}catch(Exception e) {
			assertEquals(ExceptMesgs.ERROR_BIKE_NOT_PLACED, e.getMessage());
		}
	}
	
	

	@Test
	public void testPlacingFailureOnSouthAndWest() throws Exception {
		
		try {
			bikeGridTracker.placeTheBike(new Coordinate(-10, 10, Direction.EAST));
		}catch(Exception e) {
			assertEquals(ExceptMesgs.ERROR_BIKE_NOT_PLACED, e.getMessage());
		}
	}
	
	@Test
	public void testPlacingFailureOnInvalidDirection() throws Exception {
		try {
			bikeGridTracker.placeTheBike(new Coordinate(3, 3, Direction.getDirectionByName("east1")));
		}catch(Exception e) {
			assertEquals(ExceptMesgs.ERROR_INVALID_DIRECTION, e.getMessage());
		}
	}
	
	@Test
	public void testPlacingFailureOnInvalidDirectionAndPos() throws Exception {
		try {
			bikeGridTracker.placeTheBike(new Coordinate(13, 10, Direction.getDirectionByName("east1")));
		}catch(Exception e) {
			assertEquals(ExceptMesgs.ERROR_INVALID_DIRECTION, e.getMessage());
		}
	}
	
}
