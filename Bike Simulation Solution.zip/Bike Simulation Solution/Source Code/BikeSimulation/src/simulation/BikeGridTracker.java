package simulation;

import simulation.props.Direction;
import simulation.props.ExceptMesgs;

public class BikeGridTracker {
	private int gridWidth;
	private int gridHeight;
	
	private Coordinate  bikeCoordinate = new Coordinate(-1, -1, null);
	
	public BikeGridTracker(int gridWidth, int gridHeight) {
		super();
		this.gridWidth = gridWidth;
		this.gridHeight = gridHeight;
	}
	
	
	/*
	 * this function handles turning bike to left by 90 degrees.
	 * */
	public void turnLeft() throws Exception {
		if( this.isBikeOnGrid() ) {
			this.bikeCoordinate.setDirection(this.bikeCoordinate.getDirection().turnLeft());
		}else {
			throw new Exception(ExceptMesgs.ERROR_BIKE_NOT_PLACED);
		}
	}

	/*
	 * this function handles turning bike right by 90 degrees.
	 * */
	public void turnRight() throws Exception {
		if( this.isBikeOnGrid() ) {
			this.bikeCoordinate.setDirection(this.bikeCoordinate.getDirection().turnRight());
		}else {
			throw new Exception(ExceptMesgs.ERROR_BIKE_NOT_PLACED);
		}
	}
	
	/*
	 * this function handles placing the bike in the grid
	 * */
	public void placeTheBike(Coordinate coordinate) throws Exception {
		if( (coordinate.getDirection()==null) || 
				(!Direction.isValidDirection(coordinate.getDirection().toString())) ) {
			throw new Exception(ExceptMesgs.ERROR_INVALID_DIRECTION);
		}
		
		int x = coordinate.getX();
		int y = coordinate.getY();
		
		if( (x < gridWidth) && (x >= 0) && (y>=0) && (y< gridHeight) ) {
			this.bikeCoordinate.setX(x);
			this.bikeCoordinate.setY(y);
			this.bikeCoordinate.setDirection(coordinate.getDirection());
		}
		else {
			throw new Exception(ExceptMesgs.ERROR_BIKE_NOT_PLACED);
		}
	}
	
	/*Function which determines if the bike is validated 
	 *if it isplaced on the grid.*/
	public boolean isBikeOnGrid() {
		if( (this.bikeCoordinate.getX() !=-1) 
				&& (this.bikeCoordinate.getY()!=-1) 
					&& (this.bikeCoordinate.getDirection()!=null)) {
			return true;
		}
		return false;
	}
	

	/*Returns the GPS coordinate of the bike w.r.t grid*/
	public Coordinate getGPS() throws Exception {
		if( isBikeOnGrid() ) {
			return new Coordinate(this.bikeCoordinate.getX() , this.bikeCoordinate.getY() , this.bikeCoordinate.getDirection());
		}
		throw new Exception(ExceptMesgs.ERROR_BIKE_NOT_PLACED);
	}
	
	/*Validates if moving forward is permissible and if it is, then moves
	 * the bike forward on the grid, in the direction that bike is.*/
	public void forwardMove() throws Exception {

			int x = this.bikeCoordinate.getX();
			int y = this.bikeCoordinate.getY();
			
			if(!isBikeOnGrid()) {
				throw new Exception(ExceptMesgs.ERROR_BIKE_NOT_PLACED);		
			}
			
			switch(this.bikeCoordinate.getDirection()) 
			{
				case EAST:
					if (x < (this.gridWidth-1) ) {
						x++;
						this.bikeCoordinate.setX(x);
						break;
					}
					else {
						throw new Exception(ExceptMesgs.ERROR_BIKE_CANT_GO_OUT);
					}
				case NORTH:
					if (y < (this.gridHeight-1) ) {
						y++;
						this.bikeCoordinate.setY(y);
						break;
					}
					else {
						throw new Exception(ExceptMesgs.ERROR_BIKE_CANT_GO_OUT);
					}
				case WEST:
					if (x > 0 ) {
						x--;
						this.bikeCoordinate.setX(x);
						break;
					}
					else {
						throw new Exception(ExceptMesgs.ERROR_BIKE_CANT_GO_OUT);
					}
				case SOUTH:
					if (y > 0 ) {
						y--;
						this.bikeCoordinate.setY(y);
						break;
					}
					else {
						throw new Exception(ExceptMesgs.ERROR_BIKE_CANT_GO_OUT);
					}
			}
						
	}
	
	
}
